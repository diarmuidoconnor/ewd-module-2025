import React from "react";

const FriendImage = ({friend}) => {
 
  return (
    <li>
      <h3>{` ${friend.name.first} ${friend.name.last}`}</h3>
      <img src={friend.picture.medium} />
    </li>
  );
};

export default FriendImage