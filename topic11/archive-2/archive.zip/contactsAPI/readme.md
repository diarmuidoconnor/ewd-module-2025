# In Class demo code

Run ``npm init`` followed by ``npm start`` to run