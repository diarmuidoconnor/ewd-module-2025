export default class {
    // Encrypt clear case password
    encrypt(password) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
    //compare an encrypted password to a clear case password 
    compare(password, encryptedPassword) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
  }