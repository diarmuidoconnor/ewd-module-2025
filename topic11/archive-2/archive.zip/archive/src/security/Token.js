export default class {
    generate() {
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
    decode() {
        throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }
}