export default class {
  encrypt(password) {
    throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
  }
  compare(password, encryptedPassword) {
    throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
  }
}