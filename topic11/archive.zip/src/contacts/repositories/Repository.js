export default  class {

    persist(user) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }

    merge(user) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }

    remove(userId) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }

    get(userId) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }

    getByUserName(userName) {
      throw new Error('ERR_METHOD_NOT_IMPLEMENTED');
    }

  }