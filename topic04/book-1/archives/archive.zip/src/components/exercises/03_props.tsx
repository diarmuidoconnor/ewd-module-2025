const Demo = (props: any) => {
  return <p>TODO: Exercise 3</p>;
}

export { Demo };