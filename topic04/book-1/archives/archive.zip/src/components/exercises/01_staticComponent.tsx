const Demo = () => {
  return <p>TODO: Exercise 1</p>;
}

export { Demo };