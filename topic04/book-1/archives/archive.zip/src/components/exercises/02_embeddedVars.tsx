const Demo = () => {
  return <p>TODO: Exercise 2</p>;
}

export { Demo };