const Demo = (props: any) => {
  return <p>TODO: Exercise 4</p>;
}

export { Demo };