import { useState } from "react";

interface CounterProps {
    jump?: number,
};

const Counter = ({ jump = 2 }: CounterProps) => {
    const [count, setCount] = useState(0);
    console.log(`${count} ${jump}`)

    const incrementCount = () => {
        setCount(count + jump)
    };

    return (
        <>
            <h2>Count: {count}</h2>
            <h3>Increment size: {jump}</h3>
            <button type="button" onClick={incrementCount}>
                Increment
            </button>
        </>
    );
};

export { Counter };