import { useMemo, useState } from 'react';

import { Demo as Sample01 } from './components/samples/01_staticComponent';
import { Demo as Sample02 } from './components/samples/02_embeddedVariables';
import { Demo as Sample03 } from './components/samples/03_props';
import { Demo as Sample04 } from './components/samples/04_iteration';
import { Demo as Sample05 } from './components/samples/05_hierarchy';
import { Counter as Sample06 } from './components/samples/06_state';

import { Demo as Ex01 } from './components/exercises/01_staticComponent';
import { Demo as Ex02 } from './components/exercises/02_embeddedVars';
import { Demo as Ex03 } from './components/exercises/03_props';
import { Demo as Ex04 } from './components/exercises/04_iteration';

const modules = [
  { name: 'DevOps', noLectures: 2, noPracticals: 2 },
  { name: 'Enterprise Web Dev', noLectures: 3, noPracticals: 2 },
  { name: 'Cloud Native Apps', noLectures: 2, noPracticals: 1 },
];
const languages = ['JavaScript', 'Python', 'Java'];
const frameworks = [
            { name: "React", url: "https://facebook.github.io/react/" },
            { name: "Vue", url: "https://vuejs.org/" },
            { name: "Angular", url: "https://angularjs.org/" },
        ]
export function App() {
  const [viewKey, setViewKey] = useState('sample-01');

  const views = useMemo(
    () => ({
      'sample-01': { label: 'Sample 01 - static component', element: <Sample01 /> },
      'sample-02': { label: 'Sample 02 - embedded variables', element: <Sample02 /> },
      'sample-03': {
        label: 'Sample 03 - props',
        element: <Sample03 heading="Modern Languages" languages={languages} />,
      },
      'sample-04': {
        label: 'Sample 04 - iteration',
        element: <Sample04 type="Most Popular client-side frameworks" frameworks={frameworks} />,
      },
      'sample-05': {
        label: 'Sample 05 - component hierarchy',
        element: <Sample05 frameworkProps={{type:"Most Popular client-side frameworks", frameworks}} languageProps={{heading:"Modern Languages", languages}} />,
      },
      'sample-06': {
        label: 'Sample 06 - state',
        element: <Sample06 />,
      },
      'ex-01': { label: 'Exercise 01 - static component', element: <Ex01 /> },
      'ex-02': { label: 'Exercise 02 - embedded variables', element: <Ex02 /> },
      'ex-03': {
        label: 'Exercise 03 - props',
        element: <Ex03 course="Course Modules" modules={modules} />,
      },
      'ex-04': {
        label: 'Exercise 04 - iteration',
        element: <Ex04 course="Course Modules" modules={modules} />,
      },
    }),
    []
  );

  return (
    <div className="container py-3">
      <h1 className="mb-3">React Basics Lab</h1>

      <label className="form-label" htmlFor="view">
        Choose a component
      </label>
      <select
        id="view"
        className="form-select"
        value={viewKey}
        onChange={(e) => setViewKey(e.target.value)}
      >
        {Object.entries(views).map(([key, view]) => (
          <option key={key} value={key}>
            {view.label}
          </option>
        ))}
      </select>

      <hr />

      {views[viewKey as keyof typeof views].element}
    </div>
  );
}