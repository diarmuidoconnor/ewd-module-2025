export interface LanguageProps {
  heading: string;
  languages: string[];
}

export interface Framework {
  name: string;
  url: string;
}

export interface FrameworkProps {
  frameworks: Framework[];
  type: string;
}
