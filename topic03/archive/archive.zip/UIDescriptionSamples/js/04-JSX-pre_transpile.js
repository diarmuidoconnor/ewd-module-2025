const root = (
  <div className="pad">
    <h1 className="heading">Languages</h1>
    <ul>
      <li>Javascript</li>
      <li>Java</li>
      <li>Python</li>
    </ul>
  </div>
);
const rootElement =  ReactDOM.createRoot( document.getElementById("mount-point"  ) )
rootElement.render(root);
