"use strict";

var DynamicLanguages = function DynamicLanguages() {
  return /*#__PURE__*/React.createElement("div", {
    className: "pad"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "heading"
  }, "Dynamic Languages (Component)"), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement("li", null, "Javascript"), /*#__PURE__*/React.createElement("li", null, "PHP"), /*#__PURE__*/React.createElement("li", null, "Python")));
};

var rootElement = ReactDOM.createRoot(document.getElementById("mount-point"));
rootElement.render( /*#__PURE__*/React.createElement(DynamicLanguages, null));