import React, { useContext } from "react";
import { useLocation, Route, Redirect } from "react-router-dom";
import { AuthContext } from "./authContext";

const PrivateRoute = (props) => {
  const context = useContext(AuthContext);
  const { pathname } = useLocation()

  // Destructure props from <privateRoute>
  const { component: Component, ...rest } = props;
  // console.log(props.location)
  return context.isAuthenticated ? (
    <Route {...rest} render={(props) => <Component {...props} />} />
  ) : (
    <Redirect
      to={{
        pathname: "/login",
        state: { from: pathname },
      }}
    />
  );
};

export default PrivateRoute;
