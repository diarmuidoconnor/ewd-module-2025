import React from "react";
import { useParams, Route } from "react-router-dom";

const Inbox = (props) => {
  const { userId } = useParams()
  return (
    <>
      <h1>Inbox page</h1>
      <Messages id={userId} />
      <Route path={`/inbox/:uid/statistics`} component={Stats} />
      <Route path={`/inbox/:uid/drafts`} component={Draft} />
    </>
  );
};

export const Messages = (props) => {
  return <h3>Messages for user: {props.id} </h3>;
};

const Stats = () => {
  const { uid } = useParams()
  return <h3>{`Statistical data for user ${uid}`}</h3>;
};

const Draft = () => {
  const { uid } = useParams()
  return <h3>{`Draft emails for user ${uid}`}</h3>;
};

export default Inbox;
