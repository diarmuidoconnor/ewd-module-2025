import React, { useContext } from "react";
import { useHistory } from "react-router-dom";
import { AuthContext } from "./authContext";

const AuthHeader = (props) => {
  const context = useContext(AuthContext);
  const  history  = useHistory();

  return context.isAuthenticated ? (
    <p>
      Welcome! <button onClick={() => context.signout()}>Sign out</button>
    </p>
  ) : (
    <p>
      You are not logged in{" "}
      <button onClick={() => history.push("/login")}>Login</button>
    </p>
  );
};

export default AuthHeader;
