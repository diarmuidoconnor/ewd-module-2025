# Make Plan

1. Copy `templates/plan-template.md` into the feature folder.
2. List the code changes in implementation order.
3. Note risks before coding.
