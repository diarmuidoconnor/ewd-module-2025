# Create Spec

1. Copy `templates/spec-template.md` into a new folder under `specs/`.
2. Name the folder after the feature.
3. Fill in goal, scope, relevant skills, and acceptance criteria.
