# Validate

1. Copy `templates/validation-template.md` into the feature folder.
2. Record what worked.
3. Add screenshots or short notes as evidence.
