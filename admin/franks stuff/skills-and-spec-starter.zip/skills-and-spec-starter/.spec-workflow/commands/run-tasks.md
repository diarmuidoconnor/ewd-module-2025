# Run Tasks

1. Copy `templates/tasks-template.md` into the feature folder.
2. Break the plan into small, testable tasks.
3. Complete one task at a time.
