# Example Feature Folder

Suggested files for each feature:
- `spec.md`
- `plan.md`
- `tasks.md`
- `validation.md`
