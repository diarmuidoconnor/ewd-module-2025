# Skills + Spec-Driven Workflow Starter

This starter bundle includes:
- a reusable `skills/` repo for React/TypeScript/API/UI patterns
- a minimal `.spec-workflow/` setup for feature specs, planning, tasking, and validation

Suggested use:
1. Start from your project codebase.
2. Copy in `skills/` and `.spec-workflow/`.
3. For each new feature, create a new folder under `specs/`.
4. Reference relevant skills from the feature spec.
