# Skill: Safe Null Handling

Use `??` and `?.` when API data may be missing or arrives asynchronously.
