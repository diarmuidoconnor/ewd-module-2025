# Skill: Deriving Types from OpenAPI

Generate TypeScript types from the OpenAPI spec and create a small local type layer for the app.
