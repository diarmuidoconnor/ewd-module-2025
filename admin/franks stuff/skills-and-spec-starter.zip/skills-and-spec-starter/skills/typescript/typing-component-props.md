# Skill: Typing Component Props

Always type non-trivial component props explicitly.
