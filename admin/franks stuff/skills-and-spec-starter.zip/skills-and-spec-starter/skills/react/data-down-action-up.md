# Skill: Data Down, Action Up

## What it is
A parent owns state and passes data down.
A child requests changes by calling a callback passed from the parent.

## When to use it
Use this when:
- the parent owns the state
- the child displays that state
- the child needs to trigger an update

## Why it matters
It keeps data flow predictable and avoids duplicated state.

## Pattern
```tsx
type FilterOption = "title" | "genre";

type FilterCardProps = {
  titleFilter: string;
  genreFilter: string;
  onUserInput: (type: FilterOption, value: string) => void;
};
```
