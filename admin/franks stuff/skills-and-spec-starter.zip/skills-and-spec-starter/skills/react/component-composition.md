# Skill: Component Composition

## What it is
A reusable component provides shared structure, and the page-specific content is inserted through `children`.

## When to use it
Use this when:
- two pages share the same layout
- only one section changes
- you want reuse without duplication
