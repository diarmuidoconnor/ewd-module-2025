# Skill: Conditional Rendering for Async Data

## What it is
A component renders a fallback while waiting for asynchronous data.

## Pattern
```tsx
return movie ? <MovieDetails {...movie} /> : <p>Waiting for movie details</p>;
```
