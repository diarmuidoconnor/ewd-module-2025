# Skill: Custom Hooks

## What it is
A custom hook extracts reusable stateful logic from a component.

## When to use it
Use this when:
- multiple components need the same stateful logic
- a page is cluttered with `useState` and `useEffect`
- you want UI and fetching logic separated
