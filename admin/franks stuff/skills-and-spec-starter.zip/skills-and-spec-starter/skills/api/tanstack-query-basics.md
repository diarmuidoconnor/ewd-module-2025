# Skill: TanStack Query Basics

Use TanStack Query for server-state fetching, caching, loading state, and query keys.
