# Skill: API Layer Pattern

Put HTTP request code in a dedicated API module instead of embedding it inside UI components.
