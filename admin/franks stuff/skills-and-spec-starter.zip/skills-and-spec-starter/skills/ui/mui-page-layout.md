# Skill: MUI Page Layout

Use Material UI layout components such as `Grid`, `Box`, `Paper`, and `AppBar` to structure pages.
