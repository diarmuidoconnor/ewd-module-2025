# Skill: Responsive Site Header

Use `AppBar`, `Toolbar`, buttons, and a mobile menu to keep navigation usable across viewport sizes.
