# Skill: Feature Checklist

## Checklist
- Is the user-visible goal complete?
- Are props typed?
- Is async data handled safely?
- Is API code separated from UI code?
- Are loading and error states handled?
- Does the feature match the acceptance criteria in the spec?
