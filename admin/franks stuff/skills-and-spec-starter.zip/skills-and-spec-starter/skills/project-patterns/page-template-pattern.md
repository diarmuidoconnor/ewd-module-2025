# Skill: Page Template Pattern

A page template captures shared layout while keeping part of the page configurable.
