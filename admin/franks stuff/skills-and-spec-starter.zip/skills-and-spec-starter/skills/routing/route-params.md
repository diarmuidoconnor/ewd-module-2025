# Skill: Route Params

Use `useParams()` to read IDs and other variable parts of the URL.
