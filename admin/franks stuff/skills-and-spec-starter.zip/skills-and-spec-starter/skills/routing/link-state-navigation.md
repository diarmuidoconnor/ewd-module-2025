# Skill: Link State Navigation

Use React Router link state for short-lived navigation context such as moving from a review excerpt to a full review page.
