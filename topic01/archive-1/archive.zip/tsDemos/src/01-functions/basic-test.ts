import addNumbers, { addStrings, rotate } from ".";

console.log(rotate("abc12defghi", /\d{2}/));
console.log( addNumbers(3,2) );
console.log( addStrings('enterprise','web'));

