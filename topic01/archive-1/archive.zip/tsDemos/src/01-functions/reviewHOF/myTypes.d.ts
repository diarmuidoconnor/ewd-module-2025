const sampleProfile = {
    gender: 'female',
    name: { title: 'Mrs', first: 'Lotta', last: 'Lehtola' },
    location: {
      street: [Object],
      city: 'Haapavesi',
      state: 'Finland Proper',
      country: 'Finland',
      postcode: 51366,
      coordinates: [Object],
      timezone: [Object]
    },
    email: 'lotta.lehtola@example.com',
    login: {
      uuid: '65ecbdcc-6a2c-466c-b84e-9d3274c56af7',
      username: 'orangepeacock349',
      password: 'hitman',
      salt: '6aFqm72U',
      md5: '21c23e90b3830607ca90d1d2f5ff83ed',
      sha1: '76c645d65f7195a9a110c6a24ccd9e3bc586b15d',
      sha256: '5362714bb75ef9a31d06b3791b8f36ef09d9202266e61dcccea566be14dc76dc'
    },
    dob: { date: '1960-10-31T03:59:11.715Z', age: 63 },
    registered: { date: '2015-01-22T17:09:57.275Z', age: 8 },
    phone: '05-294-289',
    cell: '043-963-83-04',
    id: { name: 'HETU', value: 'NaNNA980undefined' },
    picture: {
      large: 'https://randomuser.me/api/portraits/women/58.jpg',
      medium: 'https://randomuser.me/api/portraits/med/women/58.jpg',
      thumbnail: 'https://randomuser.me/api/portraits/thumb/women/58.jpg'
    },
    nat: 'FI'
  }

//   Trick 
export type Profile = typeof sampleProfile