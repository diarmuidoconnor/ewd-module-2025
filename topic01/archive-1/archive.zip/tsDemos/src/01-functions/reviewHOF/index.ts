import { Profile } from "./myTypes";

const response = await fetch("https://randomuser.me/api/?results=10");
const responseBody = await response.json(); // Get response body stream

const profiles: Profile[] = responseBody.results;
// console.log("Profiles: ", profiles);

// Objective: Find female profiles.
const femaleProfiles = profiles.filter((profile, index) => {
  return profile.gender === "female";
});
femaleProfiles.forEach(f =>
  console.log(`${f.gender} - ${f.name.first} ${f.name.last}`)
);
console.log('---------------------------------------')
// Objective: Find males under 40 years
const under40Males = profiles.filter(
  profile => profile.gender === "male" && profile.dob.age < 40
);
under40Males.forEach((f) =>
  console.log(`${f.gender} - ${f.dob.age} - ${f.name.first} ${f.name.first}`)
);
console.log('---------------------------------------')

// Objective - Create array of profiles' email addresses
const profileEmails = profiles.map((profile) => {
  return {
    name: `${profile.name.first} ${profile.name.last}`,
    email: profile.email,
  };
});
console.log("Email addresses: ", profileEmails);
console.log('---------------------------------------')

// Objective - Create array with profiles' ages
const profileAges = profiles.map((profile) => profile.dob.age);
console.log("Ages: ", profileAges);
console.log('---------------------------------------')

// Objective: Calculate average age of profiles.
const ageAccumulator = profiles.reduce((total, profile, index, array) => {
  return total + profile.dob.age;
}, 0);
console.log(`Average age = ${Math.round(ageAccumulator / profiles.length)}`);
console.log('---------------------------------------')

// Objective: Find youngest profile.
const youngest = profiles.reduce((min, profile) => {
  const newMin = profile.dob.age < min ? profile.dob.age : min;
  return newMin;
}, 100);
console.log(`Youngest = ${youngest}`);

